공군사관학교 모의면접 앱 - Android 프로젝트

아이패드만 있는 경우(클라우드 빌드)
1. 이 ZIP을 GitHub에 올릴 준비를 합니다. 먼저 GitHub 계정이 필요합니다.
2. GitHub에서 새 저장소(repository)를 만듭니다.
3. ZIP을 파일 앱에서 압축 해제한 뒤, AirForceMockInterviewAndroid 폴더 안의 파일과 폴더를 저장소에 업로드합니다. .github 폴더도 꼭 포함해야 자동 APK 빌드가 됩니다.
4. GitHub 저장소의 Actions 탭에서 Build APK 워크플로가 실행됐는지 확인합니다. 처음에는 저장소의 Actions 사용을 허용해야 할 수 있습니다.
5. 빌드가 성공하면 해당 실행 결과에서 Artifacts의 airforce-mock-interview-apk를 눌러 다운로드합니다. ZIP 안에 app-debug.apk가 들어 있습니다.
6. APK를 설치할 안드로이드 기기로 옮겨 설치합니다. Android는 출처를 알 수 없는 앱 설치 확인을 요구할 수 있습니다.

컴퓨터가 있는 경우
Android Studio에서 이 폴더를 열고 Android SDK Platform 35를 설치한 다음 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택하면 됩니다.

주의
- 이 프로젝트 ZIP 자체는 APK 파일이 아닙니다. APK는 위 빌드 과정을 거쳐 생성됩니다.
- 클라우드 빌드에는 GitHub 계정과 인터넷 연결이 필요합니다.
- 앱의 AI 답변 평가는 자동 내장되어 있지 않습니다. 앱에서 평가 프롬프트를 복사해 ChatGPT에 붙여 넣는 방식입니다.
